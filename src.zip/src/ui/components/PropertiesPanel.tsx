import { Box, ChevronDown, Copy, FlipHorizontal, FlipVertical, Layers, Loader2, Pencil, RotateCcw, Sparkles, Upload } from 'lucide-react';
import type React from 'react';
import { useEffect, useRef, useState } from 'react';
import { processAndCompressImage } from '@/shared/utils/image-processing';
import { ColorPicker } from '@/ui/components/ColorPicker';
import { Label } from '@/ui/design-system';
import {
  applyImageFilters,
  type DecalData,
  generateAssetTexture,
  getDefaultConfig,
  useEditorStore,
} from '@/ui/store/editor-store';
// FIX: Corrected import path to point into the preview3d subfolder
import { ImageCropModal } from './preview3d/ImageCropModal';
import { type PropertyDef, TOOL_CONFIG_MAP } from './properties/config';

function PropertySection({
  title,
  children,
  defaultOpen = false,
}: {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <details
      open={isOpen}
      onToggle={(event) => setIsOpen(event.currentTarget.open)}
      className="group rounded-xl border border-stone-200/80 bg-white/70"
    >
      <summary className="flex min-h-10 cursor-pointer list-none items-center justify-between gap-3 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-neutral-600 outline-none hover:bg-stone-50 focus-visible:ring-2 focus-visible:ring-blue-500 rounded-xl">
        <span>{title}</span>
        <ChevronDown size={14} className={`shrink-0 text-neutral-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </summary>
      <div className="border-t border-stone-100 px-3 py-3 space-y-4">{children}</div>
    </details>
  );
}

function PositionControls({
  decal,
  updateVisuals,
  saveHistory,
}: {
  decal: DecalData;
  updateVisuals: (updates: Partial<DecalData>) => void;
  saveHistory: () => void;
}) {
  const [x, setX] = useState(String(decal.position[0]));
  const [y, setY] = useState(String(decal.position[1]));
  const [isEditing, setIsEditing] = useState(false);
  const [isSizeEditing, setIsSizeEditing] = useState(false);
  const ratio = Math.max(0.01, decal.aspectRatio || 1);
  const visualWidth = decal.scaleX ?? (decal.scale * Math.max(1, ratio));
  const visualHeight = decal.scaleY ?? (decal.scale * Math.max(1, 1 / ratio));
  const [width, setWidth] = useState(String(visualWidth));
  const [height, setHeight] = useState(String(visualHeight));

  useEffect(() => {
    if (isEditing || isSizeEditing) return;
    setX(String(Number(decal.position[0].toFixed(3))));
    setY(String(Number(decal.position[1].toFixed(3))));
    setWidth(String(Number(visualWidth.toFixed(3))));
    setHeight(String(Number(visualHeight.toFixed(3))));
  }, [decal.position, visualWidth, visualHeight, isEditing, isSizeEditing]);

  const commit = () => {
    setIsEditing(false);
    const nextX = Number(x);
    const nextY = Number(y);
    if (!Number.isFinite(nextX) || !Number.isFinite(nextY)) {
      setX(String(Number(decal.position[0].toFixed(3))));
      setY(String(Number(decal.position[1].toFixed(3))));
      return;
    }
    updateVisuals({ position: [nextX, nextY, decal.position[2]] });
  };

  const commitSize = (axis: 'x' | 'y') => {
    setIsSizeEditing(false);
    const nextWidth = Number(width);
    const nextHeight = Number(height);
    if (!Number.isFinite(nextWidth) || !Number.isFinite(nextHeight) || nextWidth <= 0 || nextHeight <= 0) {
      setWidth(String(visualWidth));
      setHeight(String(visualHeight));
      return;
    }
    const currentWidth = Math.max(0.001, visualWidth);
    const currentHeight = Math.max(0.001, visualHeight);
    const ratio = currentWidth / currentHeight;
    const finalWidth = decal.lockAspectRatio === false && axis === 'y' ? currentWidth : nextWidth;
    const finalHeight = decal.lockAspectRatio === false && axis === 'x' ? currentHeight : nextHeight;
    const adjustedWidth = decal.lockAspectRatio === false ? finalWidth : (axis === 'x' ? nextWidth : nextHeight * ratio);
    const adjustedHeight = decal.lockAspectRatio === false ? finalHeight : (axis === 'y' ? nextHeight : nextWidth / ratio);
    updateVisuals({ scaleX: Math.max(0.01, adjustedWidth), scaleY: Math.max(0.01, adjustedHeight), scale: Math.max(adjustedWidth, adjustedHeight) });
  };


  return (
    <div className="space-y-2">
      <div className="text-[10px] font-medium uppercase tracking-[0.14em] text-neutral-500">Position</div>
      <div className="grid grid-cols-2 gap-2">
        <label className="flex items-center gap-2 rounded-lg border border-stone-200 bg-white px-2.5 py-2 text-[10px] text-neutral-500">
          X
          <input
            type="number"
            step="0.01"
            value={x}
            onFocus={() => { setIsEditing(true); saveHistory(); }}
            onChange={(event) => setX(event.target.value)}
            onBlur={commit}
            onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }}
            className="w-full min-w-0 bg-transparent text-right font-mono text-[11px] text-neutral-900 outline-none"
          />
        </label>
        <label className="flex items-center gap-2 rounded-lg border border-stone-200 bg-white px-2.5 py-2 text-[10px] text-neutral-500">
          Y
          <input
            type="number"
            step="0.01"
            value={y}
            onFocus={() => { setIsEditing(true); saveHistory(); }}
            onChange={(event) => setY(event.target.value)}
            onBlur={commit}
            onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }}
            className="w-full min-w-0 bg-transparent text-right font-mono text-[11px] text-neutral-900 outline-none"
          />
        </label>
      </div>
      <div className="flex items-center gap-2">
        <label className="min-w-0 flex-1 rounded-lg border border-stone-200 bg-white px-2 py-2 text-[10px] text-neutral-500">
          W
          <input type="number" min="0.01" step="0.01" value={width} onFocus={() => { setIsSizeEditing(true); saveHistory(); }} onChange={(event) => setWidth(event.target.value)} onBlur={() => commitSize('x')} onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }} className="ml-2 w-[calc(100%-1.5rem)] bg-transparent text-right font-mono text-[11px] text-neutral-900 outline-none" />
        </label>
        <label className="min-w-0 flex-1 rounded-lg border border-stone-200 bg-white px-2 py-2 text-[10px] text-neutral-500">
          H
          <input type="number" min="0.01" step="0.01" value={height} onFocus={() => { setIsSizeEditing(true); saveHistory(); }} onChange={(event) => setHeight(event.target.value)} onBlur={() => commitSize('y')} onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }} className="ml-2 w-[calc(100%-1.5rem)] bg-transparent text-right font-mono text-[11px] text-neutral-900 outline-none" />
        </label>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label className="flex items-center gap-2 text-[10px] text-neutral-600">
          <input type="checkbox" checked={decal.lockAspectRatio !== false} onChange={(event) => { saveHistory(); updateVisuals({ lockAspectRatio: event.target.checked }); }} className="accent-neutral-900" />
          Lock proportions
        </label>
        <div className="flex items-center gap-1">
          <button type="button" title="Flip horizontally" aria-pressed={Boolean(decal.flipX)} onClick={() => { saveHistory(); updateVisuals({ flipX: !decal.flipX }); }} className="rounded-lg border border-stone-200 bg-white p-2 text-neutral-600 hover:bg-stone-50"><FlipHorizontal size={14} /></button>
          <button type="button" title="Flip vertically" aria-pressed={Boolean(decal.flipY)} onClick={() => { saveHistory(); updateVisuals({ flipY: !decal.flipY }); }} className="rounded-lg border border-stone-200 bg-white p-2 text-neutral-600 hover:bg-stone-50"><FlipVertical size={14} /></button>
        </div>
      </div>
    </div>
  );
}

function SliderControl({
  prop,
  activeDecal,
  updateVisuals,
  saveHistory,
}: {
  prop: PropertyDef;
  activeDecal: DecalData;
  updateVisuals: (updates: Partial<DecalData>) => void;
  saveHistory: () => void;
}) {
  const isRotation = prop.id === 'rotationOffset';
  const isScale = prop.id === 'scale';
  const isDepth = prop.id === 'zDepth';

  const rawValue = isScale
    ? (activeDecal.scaleX ?? activeDecal.scale)
    : activeDecal[prop.id as keyof DecalData];

  const effectiveValue = typeof rawValue === 'number' ? rawValue : (prop.min ?? 0);

  let calculatedDisplay = 0;
  if (isRotation) {
    calculatedDisplay = Math.round(effectiveValue * (180 / Math.PI));
  } else if (isScale) {
    calculatedDisplay = Math.round(effectiveValue * 100);
  } else if (isDepth) {
    calculatedDisplay = Number(Number(effectiveValue).toFixed(2));
  } else {
    calculatedDisplay = Number(Number(effectiveValue).toFixed(2));
  }

  const [localText, setLocalText] = useState<string>(String(calculatedDisplay));
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (!isFocused) setLocalText(String(calculatedDisplay));
  }, [calculatedDisplay, isFocused]);

  const commitValue = (valStr: string) => {
    let num = Number(valStr);
    if (!Number.isFinite(num)) return;

    if (prop.min !== undefined) num = Math.max(prop.min, num);
    if (prop.max !== undefined) num = Math.min(prop.max, num);

    let storeNum = num;
    if (isRotation) storeNum = num * (Math.PI / 180);
    else if (isScale) storeNum = num / 100;

    const updates: Partial<DecalData> = { [prop.id]: storeNum };
    if (isScale) {
      updates.scaleX = undefined;
      updates.scaleY = undefined;
    }
    updateVisuals(updates);
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const num = Number(e.target.value);

    let storeNum = num;
    if (isRotation) storeNum = num * (Math.PI / 180);
    else if (isScale) storeNum = num / 100;

    const updates: Partial<DecalData> = { [prop.id]: storeNum };
    if (isScale) {
      updates.scaleX = undefined;
      updates.scaleY = undefined;
    }
    updateVisuals(updates);
  };

  return (
    <div className="space-y-2 min-w-0" key={prop.id}>
      <div className="flex justify-between items-center">
        <Label className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.16em] block m-0">
          {prop.label}
        </Label>
      </div>
      <div className="flex gap-3 items-center bg-white/80 border border-stone-200/70 px-2 py-1.5 rounded-xl transition-colors hover:border-stone-300">
        <input
          type="range"
          min={prop.min}
          max={prop.max}
          step={prop.step ?? 1}
          value={calculatedDisplay}
          onPointerDown={() => saveHistory()}
          onChange={handleSliderChange}
          className="flex-1 accent-black h-1 bg-black/10 rounded-full appearance-none ml-2 cursor-pointer outline-none"
        />
        <div className="flex items-center justify-center w-11 shrink-0 bg-[#fbfbfd] border border-black/5 rounded-lg px-1 py-1 shadow-none">
          <input
            type="text"
            value={isFocused ? localText : calculatedDisplay}
            onFocus={() => {
              setLocalText(String(calculatedDisplay));
              setIsFocused(true);
              saveHistory();
            }}
            onChange={(e) => setLocalText(e.target.value)}
            onBlur={(e) => {
              setIsFocused(false);
              commitValue(e.target.value);
            }}
            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
            className="w-full bg-transparent text-[11px] font-medium tracking-wider text-center font-mono outline-none text-black"
          />
        </div>
      </div>
    </div>
  );
}

function ColorControl({
  prop,
  activeDecal,
  updateVisuals,
  saveHistory,
}: {
  prop: PropertyDef;
  activeDecal: DecalData;
  updateVisuals: (updates: Partial<DecalData>) => void;
  saveHistory: () => void;
}) {
  const value = (activeDecal[prop.id as keyof DecalData] as string) || '';
  const safeColorValue = value === 'transparent' || !value ? 'transparent' : value;

  return (
    <div className="space-y-2 min-w-0" key={prop.id}>
      <Label className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.16em] block m-0">
        {prop.label}
      </Label>
      <ColorPicker
        color={safeColorValue}
        onChange={(newColor) => updateVisuals({ [prop.id]: newColor })}
        onPointerDown={() => saveHistory()}
      />
    </div>
  );
}

function TextControl({
  prop,
  activeDecal,
  updateVisuals,
  saveHistory,
}: {
  prop: PropertyDef;
  activeDecal: DecalData;
  updateVisuals: (updates: Partial<DecalData>) => void;
  saveHistory: () => void;
}) {
  const value = (activeDecal[prop.id as keyof DecalData] as string) || '';
  const [localText, setLocalText] = useState(value);
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (!isFocused) setLocalText(value);
  }, [value, isFocused]);

  return (
    <div className="space-y-2 min-w-0" key={prop.id}>
      <Label className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.16em] block m-0">
        {prop.label}
      </Label>
      <div className="bg-white/80 border border-stone-200/70 p-1 rounded-lg transition-colors hover:border-stone-300">
        <input
          type="text"
          value={isFocused ? localText : value}
          onFocus={() => {
            setLocalText(value);
            setIsFocused(true);
            saveHistory();
          }}
          onChange={(e) => setLocalText(e.target.value)}
          onBlur={() => {
            setIsFocused(false);
            if (localText !== value) updateVisuals({ [prop.id]: localText });
          }}
          onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
          className="w-full bg-transparent border-0 rounded-lg text-[11px] tracking-wide font-medium text-black px-2 py-1.5 outline-none"
        />
      </div>
    </div>
  );
}

export function PropertiesPanel({ activeDecalId }: { activeDecalId: string }) {
  const {
    decals, updateDecal, saveHistory, applyBackgroundRemoval, isProcessingBgRemoval,
    replaceDecalImage, setEditingDrawingId, setDrawingMode,
  } = useEditorStore();

  const activeDecal = decals.find((d) => d.id === activeDecalId);
  const filterRevisionRef = useRef(0);
  const filterTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const replaceInputRef = useRef<HTMLInputElement>(null);
  const [isReplacing, setIsReplacing] = useState(false);
  const [replaceError, setReplaceError] = useState<string | null>(null);

  useEffect(() => () => {
    filterRevisionRef.current += 1;
    if (filterTimerRef.current) clearTimeout(filterTimerRef.current);
  }, []);

  if (!activeDecal) return null;

  const defaults = getDefaultConfig(activeDecal.type);
  const isImageOrDrawing = activeDecal.type === 'image' || activeDecal.type === 'drawing';

  const updateVisuals = (updates: Partial<DecalData>) => {
    updateDecal(activeDecalId, updates);

    const nonRedrawProps = [
      'position', 'rotation', 'scale', 'scaleX', 'scaleY', 'rotationOffset',
      'zDepth', 'angleLimit', 'placementMode', 'visible', 'locked',
      'lockAspectRatio', 'flipX', 'flipY',
    ];
    const needsRedraw = Object.keys(updates).some((key) => !nonRedrawProps.includes(key));
    if (!needsRedraw) return;

    const requestId = ++filterRevisionRef.current;
    if (filterTimerRef.current) clearTimeout(filterTimerRef.current);

    // Slider movements are previewed immediately in state, while expensive raster
    // processing is coalesced so one drag doesn't queue dozens of filter renders.
    filterTimerRef.current = setTimeout(() => {
      filterTimerRef.current = null;
      void (async () => {
        const decal = useEditorStore.getState().decals.find((d) => d.id === activeDecalId);
        if (!decal) return;
        try {
          if (decal.type === 'image' || decal.type === 'drawing') {
            const { src: newSrc, aspectRatio } = await applyImageFilters(decal);
            if (requestId !== filterRevisionRef.current) return;
            if (!useEditorStore.getState().decals.some((item) => item.id === activeDecalId)) return;
            updateDecal(activeDecalId, { src: newSrc, aspectRatio });
          } else {
            const baseSrc = generateAssetTexture(decal);
            const { src: finalSrc, aspectRatio } = await applyImageFilters({ ...decal, originalSrc: baseSrc });
            if (requestId !== filterRevisionRef.current) return;
            if (!useEditorStore.getState().decals.some((item) => item.id === activeDecalId)) return;
            updateDecal(activeDecalId, { src: finalSrc, aspectRatio });
          }
        } catch (error) {
          console.error('Could not refresh artwork preview after property change.', error);
        }
      })();
    }, 90);
  };

  const handleReplaceImage = async (file?: File) => {
    if (!file || isReplacing) return;
    setIsReplacing(true);
    setReplaceError(null);
    try {
      const { blob, aspectRatio } = await processAndCompressImage(file);
      await replaceDecalImage(activeDecalId, blob, aspectRatio);
    } catch (error) {
      console.error('Could not replace artwork.', error);
      setReplaceError(error instanceof Error ? error.message : 'Could not replace this image. Please try again.');
    } finally {
      setIsReplacing(false);
      if (replaceInputRef.current) replaceInputRef.current.value = '';
    }
  };


  const renderControl = (prop: PropertyDef) => {
    const value = (activeDecal[prop.id as keyof DecalData] as unknown as string | number) ?? '';

    switch (prop.type) {
      case 'slider':
        return (
          <SliderControl
            key={prop.id}
            prop={prop}
            activeDecal={activeDecal}
            updateVisuals={updateVisuals}
            saveHistory={saveHistory}
          />
        );
      case 'color':
        return (
          <ColorControl
            key={prop.id}
            prop={prop}
            activeDecal={activeDecal}
            updateVisuals={updateVisuals}
            saveHistory={saveHistory}
          />
        );
      case 'text':
        return (
          <TextControl
            key={prop.id}
            prop={prop}
            activeDecal={activeDecal}
            updateVisuals={updateVisuals}
            saveHistory={saveHistory}
          />
        );
      case 'select':
        return (
          <div className="space-y-2 min-w-0" key={prop.id}>
            <Label className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.16em] block m-0">
              {prop.label}
            </Label>
            <div className="bg-white border border-black/[0.04] hover:border-black/10 p-1.5 rounded-2xl transition-all">
              <select
                className="w-full bg-transparent border-0 rounded-xl text-[11px] tracking-wide font-medium text-black p-2 outline-none cursor-pointer"
                value={value}
                onFocus={() => saveHistory()}
                onChange={(e) => updateVisuals({ [prop.id]: e.target.value })}
                style={prop.id === 'fontFamily' ? { fontFamily: String(value) } : undefined}
              >
                {prop.options?.map((opt) => (
                  <option
                    key={opt.value}
                    value={opt.value}
                    style={prop.id === 'fontFamily' ? { fontFamily: String(opt.value) } : undefined}
                  >
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        );
      case 'action':
        if (prop.actionType === 'replace-image' && isImageOrDrawing) {
          return <button key={prop.id} type="button" onClick={() => replaceInputRef.current?.click()} disabled={isReplacing} className="flex w-full items-center justify-center gap-2 rounded-xl border border-stone-200 bg-white px-3 py-2.5 text-[11px] font-medium text-neutral-700 hover:bg-stone-50 disabled:opacity-50">{isReplacing ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />} {isReplacing ? 'Replacing…' : prop.label}</button>;
        }
        if (prop.actionType === 'edit-drawing' && activeDecal.type === 'drawing') {
          return <button key={prop.id} type="button" onClick={() => { setEditingDrawingId(activeDecalId); setDrawingMode(true); }} className="flex w-full items-center justify-center gap-2 rounded-xl border border-stone-200 bg-white px-3 py-2.5 text-[11px] font-medium text-neutral-700 hover:bg-stone-50"><Pencil size={14} /> {prop.label}</button>;
        }
        return null;
      case 'button-group':
        return (
          <div className="space-y-2 min-w-0" key={prop.id}>
            <Label className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.16em] block m-0">
              {prop.label}
            </Label>
            <div className="flex bg-white border border-stone-200/80 p-1 rounded-xl shadow-sm justify-between gap-1 overflow-hidden">
              {prop.options?.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  className={`flex-1 flex justify-center items-center text-[11px] py-2 rounded-xl transition-all outline-none min-w-0 ${
                    value === opt.value
                      ? 'bg-[#fbfbfd] shadow-sm text-black font-medium border border-black/5'
                      : 'text-neutral-400 hover:text-black font-medium'
                  }`}
                  onClick={() => {
                    saveHistory();
                    updateVisuals({ [prop.id]: opt.value });
                  }}
                >
                  {opt.icon ? (
                    opt.icon
                  ) : (
                    <span className="truncate tracking-wide">{opt.label}</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const activeConfigGroups = TOOL_CONFIG_MAP[activeDecal.type] || [];

  return (
    <>
      <ImageCropModal />
      <input ref={replaceInputRef} type="file" accept="image/*" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) void handleReplaceImage(file); }} />
      {replaceError && <div role="alert" className="mx-3 mt-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[10px] leading-relaxed text-red-700">{replaceError}</div>}
      <div className="flex flex-col gap-3 pt-3 pb-6">
        {/* 3-Mode Selector */}
        <PropertySection title="Placement" defaultOpen>
          <div className="space-y-2 min-w-0">
          <Label className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.16em] block m-0">
            Placement Mode
          </Label>
          <div className="flex bg-white border border-stone-200/80 p-1 rounded-xl shadow-sm justify-between gap-1 overflow-hidden">
            <button
              type="button"
              className={`flex-1 flex justify-center items-center gap-1.5 text-[10px] py-2.5 rounded-xl transition-all outline-none min-w-0 ${
                !activeDecal.placementMode ||
                activeDecal.placementMode === 'front' ||
                activeDecal.placementMode === 'back'
                  ? 'bg-neutral-900 shadow-sm text-white font-semibold border border-neutral-900 tracking-wider uppercase'
                  : 'text-neutral-500 hover:text-neutral-900 font-medium tracking-wider uppercase'
              }`}
              onClick={() => {
                if (activeDecal.placementMode === 'front' || activeDecal.placementMode === 'back')
                  return;
                saveHistory();
                const needsReSnap = activeDecal.placementMode === 'wrap';
                updateVisuals({
                  placementMode: 'front',
                  ...(needsReSnap ? { position: [0, 0, 0], rotation: [0, 0, 0] } : {}),
                });
              }}
            >
              <Box size={12} /> Front/Back
            </button>

            <button
              type="button"
              className={`flex-1 flex justify-center items-center gap-1.5 text-[10px] py-2.5 rounded-xl transition-all outline-none min-w-0 ${
                activeDecal.placementMode === 'pass-through'
                  ? 'bg-neutral-900 shadow-sm text-white font-semibold border border-neutral-900 tracking-wider uppercase'
                  : 'text-neutral-500 hover:text-neutral-900 font-medium tracking-wider uppercase'
              }`}
              onClick={() => {
                if (activeDecal.placementMode === 'pass-through') return;
                saveHistory();
                const needsReSnap = activeDecal.placementMode === 'wrap';
                updateVisuals({
                  placementMode: 'pass-through',
                  ...(needsReSnap ? { position: [0, 0, 0], rotation: [0, 0, 0] } : {}),
                });
              }}
            >
              <Copy size={12} /> Both Sides
            </button>

            <button
              type="button"
              className={`flex-1 flex justify-center items-center gap-1.5 text-[10px] py-2.5 rounded-xl transition-all outline-none min-w-0 ${
                activeDecal.placementMode === 'wrap'
                  ? 'bg-neutral-900 shadow-sm text-white font-semibold border border-neutral-900 tracking-wider uppercase'
                  : 'text-neutral-500 hover:text-neutral-900 font-medium tracking-wider uppercase'
              }`}
              onClick={() => {
                if (activeDecal.placementMode === 'wrap') return;
                saveHistory();
                updateVisuals({ placementMode: 'wrap', scale: 1.0, rotation: [0, 0, 0] });
              }}
            >
              <Layers size={12} /> 360° Wrap
            </button>
          </div>
          </div>
        </PropertySection>

        <PropertySection title="Position & Size" defaultOpen>
          <PositionControls decal={activeDecal} updateVisuals={updateVisuals} saveHistory={saveHistory} />
        </PropertySection>

        {isImageOrDrawing && (
          <button
            type="button"
            onClick={() => applyBackgroundRemoval(activeDecalId)}
            disabled={isProcessingBgRemoval}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-tr from-neutral-50 to-neutral-100 hover:from-neutral-100 hover:to-neutral-200 border border-black/[0.04] hover:border-black/10 disabled:opacity-50 text-black rounded-2xl p-3 text-[11px] uppercase tracking-[0.1em] font-medium transition-all shadow-sm outline-none"
          >
            {isProcessingBgRemoval ? (
              <>
                <Loader2 className="animate-spin" size={14} strokeWidth={1.5} /> Processing
              </>
            ) : (
              <>
                <Sparkles size={14} strokeWidth={1.5} /> Remove Background
              </>
            )}
          </button>
        )}

        {/* Font Size Controller */}
        {activeDecal.type === 'text' && (
          <PropertySection title="Typography">
            <div className="flex items-center justify-between pr-1 border-b border-black/[0.02] pb-2">
              <h4 className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.25em] pl-1">
                Typography
              </h4>
              <button
                type="button"
                onClick={() => {
                  saveHistory();
                  updateVisuals({ fontSize: defaults.fontSize });
                }}
                className="text-neutral-400 hover:text-black transition-colors outline-none"
                title="Reset Font Size"
              >
                <RotateCcw size={12} strokeWidth={1.5} />
              </button>
            </div>
            <SliderControl
              prop={{
                id: 'fontSize',
                label: 'Font Size',
                type: 'slider',
                min: 8,
                max: 400,
                step: 1,
              }}
              activeDecal={activeDecal}
              updateVisuals={updateVisuals}
              saveHistory={saveHistory}
            />
          </PropertySection>
        )}

        {/* Z-Depth & Smear Controllers */}
        {activeDecal.placementMode !== 'wrap' && (
          <PropertySection title="3D Projection">
            <div className="flex items-center justify-between pr-1 border-b border-black/[0.02] pb-2">
              <h4 className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.25em] pl-1">
                3D Projection
              </h4>
              <button
                type="button"
                onClick={() => {
                  saveHistory();
                  updateVisuals({
                    zDepth: defaults.zDepth ?? 0.12,
                    angleLimit: defaults.angleLimit ?? 65,
                  });
                }}
                className="text-neutral-400 hover:text-black transition-colors outline-none"
                title="Reset Projection"
              >
                <RotateCcw size={12} strokeWidth={1.5} />
              </button>
            </div>

            <SliderControl
              prop={{
                id: 'zDepth',
                label: 'Projection Depth',
                type: 'slider',
                min: 0.01,
                max: 15,
                step: 0.01,
              }}
              activeDecal={activeDecal}
              updateVisuals={updateVisuals}
              saveHistory={saveHistory}
            />

            <p className="text-[10px] leading-relaxed text-neutral-400">Higher projection depth can reach around curved fabric and may affect unintended surfaces. Increase it gradually.</p>
            <SliderControl
              prop={{
                id: 'angleLimit',
                label: 'Surface Angle Limit',
                type: 'slider',
                min: 10,
                max: 90,
                step: 1,
              }}
              activeDecal={activeDecal}
              updateVisuals={updateVisuals}
              saveHistory={saveHistory}
            />
          </PropertySection>
        )}

        {activeConfigGroups.map((group) => (
          <PropertySection key={group.id} title={group.title}>
            <div className="flex items-center justify-between pr-1 border-b border-black/[0.02] pb-2">
              <h4 className="text-[10px] font-medium text-neutral-500 uppercase tracking-[0.25em] pl-1">
                {group.title}
              </h4>
              <button
                type="button"
                onClick={() => {
                  saveHistory();
                  const resetValues: Partial<DecalData> = {};
                  group.properties.forEach((p) => {
                    (resetValues as Record<string, unknown>)[p.id] = defaults[p.id as keyof DecalData];
                  });
                  updateVisuals(resetValues);
                }}
                className="text-neutral-400 hover:text-black transition-colors outline-none"
                title="Reset Section"
              >
                <RotateCcw size={12} strokeWidth={1.5} />
              </button>
            </div>
            <div className="space-y-4">{group.properties.map(renderControl)}</div>
          </PropertySection>
        ))}
      </div>
    </>
  );
}
